#' dod:
#'
#'
#' The \strong{dod} package
#'
#' @section dod functions:
#' \code{\link{dod}}:
#'
#' @docType package
#' @name dod
#' @import surveillance
#' @import MASS
#' @import plotrix
NULL

